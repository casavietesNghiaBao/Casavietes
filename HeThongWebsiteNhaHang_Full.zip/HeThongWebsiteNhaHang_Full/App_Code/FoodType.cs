﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for FoodType
/// </summary>
public class FoodType
{
    public FoodType()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public int foodtype_id { get; set; }

    public string foodtype_name { get; set; }
}