﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for QLWeb
/// </summary>
public class QLWeb
{
    public QLWeb()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public int id_nh { get; set; }
    public string ten_nh { get; set; }
    public string diachi_nh { get; set; }
    public string sdt_nh { get; set; }
    public string email_nh { get; set; }
    public string gt_nh { get; set; }
    public string banner_nh { get; set; }
    public string anh_nh { get; set; }
}