﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for table
/// </summary>
public class table
{
    public table()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public int table_id { get; set; }
    public string table_name { get; set; }
    public bool table_status { get; set; }
    public int table_description { get; set; }
}